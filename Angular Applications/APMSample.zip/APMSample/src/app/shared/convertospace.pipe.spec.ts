import { ConvertospacePipe } from './convertospace.pipe';

describe('ConvertospacePipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertospacePipe();
    expect(pipe).toBeTruthy();
  });
});
