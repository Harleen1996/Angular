import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productUrl:string = './api/products.products.json';
  constructor(private httpClient:HttpClient){}

}
